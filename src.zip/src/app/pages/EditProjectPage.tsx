import { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { ArrowLeft, FileText, Save, CheckCircle } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { motion } from "motion/react";
import { Header } from "../components/Header";

export default function EditProjectPage() {
  const navigate = useNavigate();
  const { projectId } = useParams();
  const [formData, setFormData] = useState({
    projectName: "",
    projectType: "مطاعم وكافيهات",
    description: "",
    targetMarket: "",
    budget: "",
    timeline: "",
    team: "",
    competitors: ""
  });

  useEffect(() => {
    // Load project data from localStorage
    const projects = JSON.parse(localStorage.getItem("projects") || "[]");
    const project = projects.find((p: any) => p.id === parseInt(projectId || "0"));
    
    if (project) {
      setFormData({
        projectName: project.projectName || "",
        projectType: project.projectType || "مطاعم وكافيهات",
        description: project.description || "",
        targetMarket: project.targetMarket || "",
        budget: project.budget || "",
        timeline: project.timeline || "",
        team: project.team || "",
        competitors: project.competitors || ""
      });
    } else {
      // If project not found, redirect to my projects
      navigate("/dashboard/my-projects");
    }
  }, [projectId, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Update project in localStorage
    const projects = JSON.parse(localStorage.getItem("projects") || "[]");
    const updatedProjects = projects.map((p: any) => {
      if (p.id === parseInt(projectId || "0")) {
        return {
          ...p,
          ...formData,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });
    
    localStorage.setItem("projects", JSON.stringify(updatedProjects));
    
    // Navigate back to my projects
    navigate("/dashboard/my-projects");
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50 dark:bg-gray-100 p-6 lg:p-8" dir="rtl">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Header */}
          <motion.div 
            className="bg-white dark:bg-gray-200 rounded-xl p-8 border border-gray-200 dark:border-gray-300 shadow-sm"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-14 h-14 rounded-lg bg-[#C6A75E] dark:bg-secondary-600 flex items-center justify-center">
                    <FileText className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-4xl font-bold text-[#08312d] dark:text-gray-900">تعديل المشروع</h1>
                </div>
                <p className="text-gray-600 dark:text-gray-700 text-lg font-medium mr-[68px] font-[Changa]">عدّل بيانات مشروعك وقم بحفظ التغييرات</p>
              </div>
            </div>
          </motion.div>

          {/* Form */}
          <motion.form 
            onSubmit={handleSubmit} 
            className="bg-white dark:bg-gray-200 rounded-xl p-8 border border-gray-200 dark:border-gray-300 shadow-sm space-y-6"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Project Name */}
              <div className="md:col-span-2">
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  اسم المشروع <span className="text-red-600">*</span>
                </label>
                <Input
                  type="text"
                  name="projectName"
                  value={formData.projectName}
                  onChange={handleChange}
                  placeholder="مثال: مقهى النخبة"
                  className="w-full bg-gray-50 dark:bg-gray-100 border-gray-300 dark:border-gray-400 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 rounded-lg px-4 py-3 text-base font-medium font-[Changa] focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E]"
                  required
                />
              </div>

              {/* Project Type */}
              <div>
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  نوع المشروع <span className="text-red-600">*</span>
                </label>
                <div className="w-full bg-gray-50 dark:bg-gray-100 border border-gray-300 dark:border-gray-400 rounded-lg px-4 py-3 text-[#08312d] dark:text-gray-900 font-medium text-base font-[Changa]">
                  مطاعم وكافيهات
                </div>
                <input type="hidden" name="projectType" value="مطاعم وكافيهات" />
              </div>

              {/* Budget */}
              <div>
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  الميزانية المتوقعة (ر.س) <span className="text-red-600">*</span>
                </label>
                <Input
                  type="text"
                  name="budget"
                  value={formData.budget}
                  onChange={handleChange}
                  placeholder="مثال: 300,000"
                  className="w-full bg-gray-50 dark:bg-gray-100 border-gray-300 dark:border-gray-400 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 rounded-lg px-4 py-3 text-base font-medium font-[Changa] focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E]"
                  required
                />
              </div>

              {/* Description */}
              <div className="md:col-span-2">
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  وصف المشروع <span className="text-red-600">*</span>
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="مثال: مقهى عصري يقدم القهوة المختصة والمعجنات الطازجة مع أجواء مريحة للعمل والدراسة..."
                  className="w-full bg-gray-50 dark:bg-gray-100 border border-gray-300 dark:border-gray-400 rounded-lg px-4 py-3 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 resize-none font-medium text-base focus:outline-none focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E] font-[Changa]"
                  rows={5}
                  required
                />
              </div>

              {/* Target Market */}
              <div>
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  السوق المستهدف <span className="text-red-600">*</span>
                </label>
                <Input
                  type="text"
                  name="targetMarket"
                  value={formData.targetMarket}
                  onChange={handleChange}
                  placeholder="مثال: العائلات والشباب في الأحياء الراقية"
                  className="w-full bg-gray-50 dark:bg-gray-100 border-gray-300 dark:border-gray-400 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 rounded-lg px-4 py-3 text-base font-medium font-[Changa] focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E]"
                  required
                />
              </div>

              {/* Timeline */}
              <div>
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  المدة الزمنية المتوقعة <span className="text-red-600">*</span>
                </label>
                <Input
                  type="text"
                  name="timeline"
                  value={formData.timeline}
                  onChange={handleChange}
                  placeholder="مثال: 4-6 أشهر"
                  className="w-full bg-gray-50 dark:bg-gray-100 border-gray-300 dark:border-gray-400 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 rounded-lg px-4 py-3 text-base font-medium font-[Changa] focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E]"
                  required
                />
              </div>

              {/* Team */}
              <div>
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  حجم الفريق المتوقع
                </label>
                <Input
                  type="text"
                  name="team"
                  value={formData.team}
                  onChange={handleChange}
                  placeholder="مثال: 8-12 موظف (طهاة، باريستا، خدمة)"
                  className="w-full bg-gray-50 dark:bg-gray-100 border-gray-300 dark:border-gray-400 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 rounded-lg px-4 py-3 text-base font-medium font-[Changa] focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E]"
                />
              </div>

              {/* Competitors */}
              <div>
                <label className="block text-[#08312d] dark:text-gray-900 font-bold text-base mb-2 font-[Changa]">
                  المنافسون الرئيسيون
                </label>
                <Input
                  type="text"
                  name="competitors"
                  value={formData.competitors}
                  onChange={handleChange}
                  placeholder="مثال: ستاربكس، كوستا كافيه، مقاهي محلية"
                  className="w-full bg-gray-50 dark:bg-gray-100 border-gray-300 dark:border-gray-400 text-[#08312d] dark:text-gray-900 placeholder:text-gray-400 rounded-lg px-4 py-3 text-base font-medium font-[Changa] focus:ring-2 focus:ring-[#C6A75E] focus:border-[#C6A75E]"
                />
              </div>
            </div>

            {/* Submit Button - Fixed at bottom */}
            <div className="flex gap-4 pt-6 border-t-2 border-gray-200 dark:border-gray-300 sticky bottom-0 bg-white dark:bg-gray-200 pb-4 -mb-4 -mx-8 px-8">
              <Button
                type="submit"
                className="flex-1 py-6 bg-[#C6A75E] dark:bg-secondary-600 hover:bg-[#a88f4e] dark:hover:bg-secondary-700 text-white font-bold text-lg rounded-lg transition-all duration-300 font-[Changa] shadow-lg"
              >
                <Save className="w-6 h-6 ml-2" />
                حفظ التعديلات
              </Button>
              
              <Link
                to="/dashboard/my-projects"
                className="bg-gray-50 dark:bg-gray-100 border-2 border-gray-300 dark:border-gray-400 rounded-lg px-8 py-4 text-gray-700 dark:text-gray-800 hover:bg-gray-100 dark:hover:bg-gray-300 hover:border-gray-400 dark:hover:border-gray-500 transition-all flex items-center gap-2 font-semibold font-[Changa]"
              >
                إلغاء
              </Link>
            </div>
          </motion.form>

        </div>
      </div>
    </>
  );
}
