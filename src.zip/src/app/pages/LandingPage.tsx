import { Link } from "react-router";
import { ArrowLeft } from "lucide-react";
const logoImage = "/assets/logo-landing.png";

export default function LandingPage() {
  return (
    <div 
      className="min-h-screen flex items-center justify-center p-8 relative overflow-hidden" 
      dir="rtl"
      style={{ background: '#0a2e2a' }}
    >
      <div className="max-w-7xl mx-auto relative z-10 w-full">
        {/* Main Content Container */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          
          {/* Right Side: Logo (Clean, No Border) */}
          <div className="flex justify-center items-center order-2 lg:order-1">
            {/* Logo + Triangles Wrapper - All centered together */}
            <div className="relative w-[500px] h-[500px] flex items-center justify-center">
              {/* Geometric Pattern Behind Logo - Now properly centered */}
              <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
                {/* Remove polygon */}
              </svg>
              
              {/* Logo - Centered on top of triangles */}
              <img 
                src={logoImage} 
                alt="مُـقــــدِم" 
                className="relative z-10 w-auto max-w-full h-auto drop-shadow-2xl m-[0px]"
              />
            </div>
          </div>

          {/* Left Side: Text Content */}
          <div className="text-white space-y-6 order-1 lg:order-2">
            {/* Main Title */}
            <h1 className="text-7xl font-bold text-white">
              مُـقــــدِم
            </h1>

            {/* Description */}
            <p className="text-lg leading-relaxed max-w-xl font-[Changa]" style={{ color: '#bdc6c1' }}>
              مساعدك الذكي لدراسات الجدوى الاحترافية واتخاذ القرارات الاستثمارية بثقة. 
              نحوّل أفكارك إلى مشاريع ناجحة بذكاء اصطناعي متقدم.
            </p>

            {/* CTA Button */}
            <div className="pt-4">
              <Link
                to="/auth"
                className="inline-flex items-center justify-center gap-3 px-10 py-4 bg-gradient-to-r from-[#C6A75E] to-[#a88f4e] hover:shadow-xl hover:shadow-[#C6A75E]/30 rounded-full text-white text-base font-bold transition-all duration-300"
              >
                <span className="font-[Changa]">ابدأ الآن</span>
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}