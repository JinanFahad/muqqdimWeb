import { useState, useEffect } from "react";
import { Link } from "react-router";
import {
  ArrowLeft,
  PresentationIcon,
  Download,
  FolderOpen,
  FileText,
  Loader2,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";
import { Header } from "../components/Header";
import { useLanguage } from "../contexts/LanguageContext";

export default function PitchDeckPage() {
  const { language } = useLanguage();
  const isAr = language === "ar";
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingProject, setGeneratingProject] = useState<any>(null);

  useEffect(() => {
    const savedProjects = JSON.parse(localStorage.getItem("projects") || "[]");
    setProjects(savedProjects);
  }, []);

  const handleExportPitchDeck = (project: any) => {
    setIsGenerating(true);
    setGeneratingProject(project);

    // Simulate a delay to mimic the generation process
    setTimeout(() => {
      setIsGenerating(false);
      setGeneratingProject(null);
      // Here you would actually trigger the Pitch Deck download
      alert(
        isAr
          ? `تم تحميل العرض التقديمي لمشروع: ${project.projectName}`
          : `Pitch Deck downloaded for project: ${project.projectName}`,
      );
    }, 3000);
  };

  return (
    <>
      <Header />
      <div
        className="min-h-screen bg-transparent dark:bg-gray-100 p-6 lg:p-8"
        dir={isAr ? "rtl" : "ltr"}
      >
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Header */}
          <motion.div
            className="bg-white dark:bg-gray-200 rounded-xl p-8 border border-gray-200 dark:border-gray-300 shadow-sm"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-14 h-14 rounded-lg bg-[#C6A75E] dark:bg-secondary-600 flex items-center justify-center">
                    <PresentationIcon className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-4xl font-bold text-[#08312d] dark:text-gray-900">
                    {isAr ? "إعداد العرض الاستثماري" : "Pitch Deck"}
                  </h1>
                </div>
                <p className="text-gray-600 dark:text-gray-700 text-lg font-medium mr-[68px] font-[Changa]">
                  {isAr
                    ? "قم بتصدير عرض تقديمي احترافي (Pitch Deck) لمشروعك"
                    : "Export a professional Pitch Deck for your project"}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Info Section */}
          <motion.div
            className="bg-white dark:bg-gray-200 rounded-xl p-6 border border-gray-200 dark:border-gray-300 shadow-sm"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-xl font-bold text-[#08312D] dark:text-white mb-3">
              {isAr ? "ما هو Pitch Deck؟" : "What is a Pitch Deck?"}
            </h2>
            <p className="text-[#08312D]/70 dark:text-white/60 mb-4 leading-relaxed">
              {isAr
                ? "العرض التقديمي (Pitch Deck) هو عرض مختصر واحترافي يستخدم لجذب المستثمرين والشركاء."
                : "A Pitch Deck is a concise professional presentation used to attract investors and partners."}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {[
                {
                  title: isAr ? "المشكلة والحل" : "Problem & Solution",
                  desc: isAr
                    ? "المشكلة التي يحلها مشروعك والحل المقترح"
                    : "The problem your project solves and the proposed solution",
                },
                {
                  title: isAr ? "السوق المستهدف" : "Target Market",
                  desc: isAr
                    ? "حجم السوق والفئة المستهدفة"
                    : "Market size and target audience",
                },
                {
                  title: isAr ? "نموذج العمل" : "Business Model",
                  desc: isAr
                    ? "كيف سيحقق مشروعك الإيرادات"
                    : "How your project will generate revenue",
                },
                {
                  title: isAr ? "التوقعات المالية" : "Financial Projections",
                  desc: isAr
                    ? "الإيرادات والتكاليف المتوقعة"
                    : "Expected revenues and costs",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="glass-lighter rounded-lg p-4 text-right"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#C6A75E] to-[#a88f4e] flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-xs">
                        {index + 1}
                      </span>
                    </div>
                    <h4 className="text-[#08312D] dark:text-white font-bold text-sm">
                      {item.title}
                    </h4>
                  </div>
                  <p className="text-[#08312D]/60 dark:text-white/50 text-xs mr-9">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Projects List */}
          {projects.length === 0 ? (
            <div className="glass rounded-2xl p-12 text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#C6A75E] to-[#a88f4e] flex items-center justify-center mx-auto mb-6">
                <FolderOpen className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#08312D] dark:text-white mb-3">
                {isAr ? "لا توجد مشاريع بعد" : "No projects yet"}
              </h3>
              <p className="text-[#08312D]/60 dark:text-white/50 mb-6 max-w-md mx-auto">
                أنشئ مشروعك الأول لتتمكن من تصدير عرض تقديمي احترافي له
              </p>
              <Link
                to="/dashboard/feasibility-study"
                className="inline-flex items-center gap-2 glass rounded-xl px-6 py-3 text-[#08312D] dark:text-white hover:scale-105 transition-transform border border-amber-500"
              >
                <span>{isAr ? "إنشاء مشروع جديد" : "Create New Project"}</span>
                <FileText className="w-4 h-4" />
              </Link>
            </div>
          ) : (
            <div>
              <h2 className="text-xl font-bold text-[#08312D] dark:text-white mb-4">
                {isAr
                  ? "اختر مشروعاً لتصدير Pitch Deck"
                  : "Select a project to export Pitch Deck"}
              </h2>
              <div className="grid grid-cols-1 gap-4">
                {projects.map((project) => (
                  <div
                    key={project.id}
                    className="glass rounded-2xl p-6 hover:scale-[1.02] transition-all duration-300"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#C6A75E] to-[#a88f4e] flex items-center justify-center flex-shrink-0">
                          <PresentationIcon className="w-7 h-7 text-white" />
                        </div>

                        <div className="flex-1 min-w-0">
                          <h3 className="text-[#08312D] dark:text-white font-bold text-lg mb-2">
                            {project.projectName}
                          </h3>
                          <p className="text-[#08312D]/60 dark:text-white/50 text-sm mb-3 line-clamp-2">
                            {project.description}
                          </p>

                          <div className="flex flex-wrap items-center gap-4 text-xs">
                            <span className="glass-lighter px-3 py-1 rounded-lg text-[#385650] dark:text-primary-600">
                              {project.projectType}
                            </span>
                            <span className="text-[#08312D]/70 dark:text-white/60">
                              {isAr ? "الميزانية" : "Budget"}: {project.budget}{" "}
                              {isAr ? "ر.س" : "SAR"}
                            </span>
                            <span className="text-[#08312D]/70 dark:text-white/60">
                              {isAr ? "المدة" : "Duration"}: {project.timeline}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => handleExportPitchDeck(project)}
                        className="bg-[#FFF9F0] dark:bg-secondary-50 border-2 border-[#C6A75E] dark:border-secondary-600 hover:bg-[#C6A75E] hover:text-white text-[#C6A75E] dark:text-secondary-700 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold shadow-sm transition-all"
                      >
                        {isGenerating &&
                        generatingProject?.id === project.id ? (
                          <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                          <>
                            <PresentationIcon className="w-5 h-5" />
                            <span>{isAr ? "عرض تقديمي" : "Pitch Deck"}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Loading Modal */}
      {isGenerating && generatingProject && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-6"
          dir={isAr ? "rtl" : "ltr"}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white dark:bg-gray-200 rounded-2xl p-8 max-w-md w-full shadow-2xl border border-gray-200 dark:border-gray-300"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-[#C6A75E] dark:bg-secondary-600 flex items-center justify-center mb-6 shadow-lg">
                <Loader2 className="w-10 h-10 text-white animate-spin" />
              </div>

              <h3 className="text-2xl font-bold text-[#08312d] dark:text-gray-900 mb-3">
                {isAr ? "جاري التحضير" : "Preparing..."}
              </h3>

              <p className="text-gray-600 dark:text-gray-700 text-lg leading-relaxed mb-2 font-[Changa]">
                {isAr
                  ? "سيقوم الذكاء الاصطناعي بإنشاء عرضك التقديمي وتحميله"
                  : "AI will generate and download your pitch deck"}
              </p>

              <p className="text-[#C6A75E] dark:text-secondary-700 font-bold text-lg font-[Changa]">
                {isAr ? "الرجاء الانتظار..." : "Please wait..."}
              </p>

              <div className="mt-6 w-full bg-gray-200 dark:bg-gray-300 rounded-full h-2 overflow-hidden">
                <motion.div
                  className="h-full bg-[#C6A75E] dark:bg-secondary-600"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 3, ease: "linear" }}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}
